package calculadora;
import java.util.Scanner;
public class calculadora {

 public static Scanner sc = new Scanner(System.in);

 public static void print(String text) {
 System.out.println(text);
}

 public static String scan(String text) {
 print(text);
 return sc.next();
}

 public static float scanFloat(String text) {
 print(text);
 return sc.nextFloat();
}

 public static int scanInt(String text) {
 print(text);
 return sc.nextInt();
}int ndv;
 public static int ask() {
 int ndv = scanInt("Quantos numeros terão na operação? (de 1 a 5 nmeros): ");
 return ndv;
}
 public static void main(String[] args) {
 print("Qual operação você deseja realizar:");
 print("1 SOMA");
 print("2 SUBTRAÇÃO");
 print("3 MULTIPLICAÇÃO");
 print("4 DIVISÃO");
 print("5 RAIZ QUADRADA");
 print("6 POTENCIAÇÃO");
 print("7 PORCENTAGEM");

 double soma = 0, multiplicação = 0, divisão = 0, subtração = 0, potenciação = 0, porcentagem = 0, raiz_quadrada = 0;

 int ndv;
 do {
 ndv = ask();
 if(ndv>5) print("a quantidade de numeros tem que ser menos que 6");
 if(ndv<1) print("a quantidade de numeros tem que ser mais que 0"); 
 }while(ndv>5 || ndv<1);
 int opt = scanInt("qual operação você deseja realizar(digite o numero referente a operação)");
for(int x = 1; x<=ndv; x++) {
 double n = scanFloat("digite seu numero "+x+": ");
 soma += n;

if(subtração == 0) subtração = n; 
     else subtração = subtração -= n;

if(potenciação == 0) potenciação = n; 
    else potenciação = Math.pow(potenciação, n);

 if(multiplicação == 0) multiplicação = n;
     else multiplicação *= n;

 if(divisão == 0) divisão = n; 
     else divisão = divisão/n; 

 if(porcentagem == 0) porcentagem = n; 
     else porcentagem = n*100/porcentagem; 

 raiz_quadrada += Math.sqrt(n);
}

 switch(opt) {
 case 1:
 print("Soma: "+soma);
break;
 case 2:
 print("Subtração: "+subtração);
break;
case 3:
 print("Multiplicação: "+multiplicação);
break;
 case 4:
print("Divisão: "+divisão
break;
case 5:
print("Raiz Quadrada: "+raiz_quadrada);
break;
case 6:
 print("Potenciação: "+potenciação);
break;
case 7:
 print("Porcentagem: "+porcentagem);
break;
}

 sc.close();
}

}